﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using EnsdProj.Models;

namespace EnsdProj.Models
{
    public class EnsdProjContext : DbContext
    {
        public EnsdProjContext()
        {
        }

        public EnsdProjContext (DbContextOptions<EnsdProjContext> options)
            : base(options)
        {
        }

        public DbSet<EnsdProj.Models.Product> Product { get; set; }

        public DbSet<EnsdProj.Models.Order> Order { get; set; }

        public DbSet<EnsdProj.Models.ProductOrder> ProductOrder { get; set; }

       // public DbSet<EnsdProj.Models.Supplier> Supplier { get; set; }

        public DbSet<EnsdProj.Models.Customer> Customer { get; set; }

        public DbSet<EnsdProj.Models.Login> Login { get; set; }

        public DbSet<EnsdProj.Models.Order> Orders { get; set; }
        // This is Model Builder
        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<ProductOrder>()
                .HasKey(bo => new { bo.ID, bo.OrderID });

            builder.Entity<ProductOrder>()
                .HasOne(bo => bo.Product)
                .WithMany(b => b.ProductOrders)
                .HasForeignKey(bo => bo.ID);

            builder.Entity<ProductOrder>()
                .HasOne(bo => bo.Product)
                .WithMany(o => o.ProductOrders)
                .HasForeignKey(bo => bo.OrderID);
        }
    }
}
