﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace EnsdProj.Migrations
{
    public partial class ProductOrder1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ProductOrder",
                columns: table => new
                {
                    ID = table.Column<string>(nullable: false),
                    ProductID = table.Column<string>(nullable: true),
                    OrderID = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductOrder", x => x.ID);
                    table.ForeignKey(
                        name: "FK_ProductOrder_Order_OrderID",
                        column: x => x.OrderID,
                        principalTable: "Order",
                        principalColumn: "OrderID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ProductOrder_Product_ProductID",
                        column: x => x.ProductID,
                        principalTable: "Product",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ProductOrder_OrderID",
                table: "ProductOrder",
                column: "OrderID");

            migrationBuilder.CreateIndex(
                name: "IX_ProductOrder_ProductID",
                table: "ProductOrder",
                column: "ProductID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ProductOrder");
        }
    }
}
