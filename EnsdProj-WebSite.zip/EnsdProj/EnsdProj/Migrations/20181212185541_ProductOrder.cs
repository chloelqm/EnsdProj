﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace EnsdProj.Migrations
{
    public partial class ProductOrder : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ProductOrder_Order_OrderID",
                table: "ProductOrder");

            migrationBuilder.DropForeignKey(
                name: "FK_ProductOrder_Product_ProductID",
                table: "ProductOrder");

            migrationBuilder.DropPrimaryKey(
                name: "PK_ProductOrder",
                table: "ProductOrder");

            migrationBuilder.RenameColumn(
                name: "ProductID",
                table: "ProductOrder",
                newName: "OrderID1");

            migrationBuilder.RenameIndex(
                name: "IX_ProductOrder_ProductID",
                table: "ProductOrder",
                newName: "IX_ProductOrder_OrderID1");

            migrationBuilder.AlterColumn<string>(
                name: "OrderID",
                table: "ProductOrder",
                nullable: false,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AddPrimaryKey(
                name: "PK_ProductOrder",
                table: "ProductOrder",
                columns: new[] { "ID", "OrderID" });

            migrationBuilder.AddForeignKey(
                name: "FK_ProductOrder_Product_OrderID",
                table: "ProductOrder",
                column: "OrderID",
                principalTable: "Product",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ProductOrder_Order_OrderID1",
                table: "ProductOrder",
                column: "OrderID1",
                principalTable: "Order",
                principalColumn: "OrderID",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ProductOrder_Product_OrderID",
                table: "ProductOrder");

            migrationBuilder.DropForeignKey(
                name: "FK_ProductOrder_Order_OrderID1",
                table: "ProductOrder");

            migrationBuilder.DropPrimaryKey(
                name: "PK_ProductOrder",
                table: "ProductOrder");

            migrationBuilder.RenameColumn(
                name: "OrderID1",
                table: "ProductOrder",
                newName: "ProductID");

            migrationBuilder.RenameIndex(
                name: "IX_ProductOrder_OrderID1",
                table: "ProductOrder",
                newName: "IX_ProductOrder_ProductID");

            migrationBuilder.AlterColumn<string>(
                name: "OrderID",
                table: "ProductOrder",
                nullable: true,
                oldClrType: typeof(string));

            migrationBuilder.AddPrimaryKey(
                name: "PK_ProductOrder",
                table: "ProductOrder",
                column: "ID");

            migrationBuilder.AddForeignKey(
                name: "FK_ProductOrder_Order_OrderID",
                table: "ProductOrder",
                column: "OrderID",
                principalTable: "Order",
                principalColumn: "OrderID",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ProductOrder_Product_ProductID",
                table: "ProductOrder",
                column: "ProductID",
                principalTable: "Product",
                principalColumn: "ID",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
