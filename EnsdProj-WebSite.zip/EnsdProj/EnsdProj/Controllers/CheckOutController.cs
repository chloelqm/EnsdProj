﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;


using Microsoft.EntityFrameworkCore;
using EnsdProj.Models;
using EnsdProj.Controllers.API;

namespace EnsdProj.Controllers
{
    public class CheckOutController : Controller
    {
        private readonly EnsdProjContext _context;

        public CheckOutController(EnsdProjContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        string SessionKeyName = "myshoppingcart";

        public async Task<IActionResult> Confirm()
        {
            Dictionary<string, CartItem> cart;
            if (HttpContext.Session.GetString(SessionKeyName) == null)
            {
                cart = new Dictionary<string, CartItem>();
            }
            else
            {
                cart = HttpContext.Session
                     .Get<Dictionary<string, CartItem>>(SessionKeyName);
            }
            if (cart.Count() == 0)
            {
                // empty cart
                return RedirectToAction("Index", "Products");
            }
            else
            {
                // create the order
                Order order = new Order();
                order.OrderDate = System.DateTime.Now;
                order.Price = cart.Values.Sum(i => i.Price * i.Qty);
                await _context.AddAsync<Order>(order);
                var orderID = order.OrderID;
                foreach (CartItem i in cart.Values)
                {
                    ProductOrder productOrder = new ProductOrder();
                    productOrder.ID = i.ProductID;
                    productOrder.OrderID = orderID;
                    await _context.AddAsync<ProductOrder>(productOrder);
                }
                await _context.SaveChangesAsync();
                // empty the cart
                cart = new Dictionary<string, CartItem>();
                HttpContext.Session
                   .Set<Dictionary<string, CartItem>>(SessionKeyName, cart);
                return RedirectToAction("Index", "Orders");
            }
        }
    }
}