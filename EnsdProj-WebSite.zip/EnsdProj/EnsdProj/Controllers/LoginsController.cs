﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace EnsdProj.Models
{
    public class LoginsController : Controller
    {
        private readonly EnsdProjContext _context;

        public LoginsController(EnsdProjContext context)
        {
            _context = context;
        }


        // GET: Logins
        public async Task<IActionResult> Index()
        {
            return View(await _context.Login.ToListAsync());
        }

        public IActionResult Logout()
        {
            return View();
        }


        public IActionResult Register()
        {
            return View();
        }


        // GET: Logins/Details/5
        public async Task<IActionResult> Details(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var login = await _context.Login
                .FirstOrDefaultAsync(m => m.LoginID == id);
            if (login == null)
            {
                return NotFound();
            }

            return View(login);
        }

        // GET: Logins/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Logins/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("LoginID,Password")] Login login)
        {
            if (ModelState.IsValid)
            {
                _context.Add(login);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(login);
        }

        // GET: Logins/Edit/5
        public async Task<IActionResult> Edit(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var login = await _context.Login.FindAsync(id);
            if (login == null)
            {
                return NotFound();
            }
            return View(login);
        }

        // POST: Logins/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, [Bind("LoginID,Password")] Login login)
        {
            if (id != login.LoginID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(login);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!LoginExists(login.LoginID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(login);
        }

        // GET: Logins/Delete/5
        public async Task<IActionResult> Delete(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var login = await _context.Login
                .FirstOrDefaultAsync(m => m.LoginID == id);
            if (login == null)
            {
                return NotFound();
            }

            return View(login);
        }


        // POST: Logins/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            var login = await _context.Login.FindAsync(id);
            _context.Login.Remove(login);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool LoginExists(string id)
        {
            return _context.Login.Any(e => e.LoginID == id);
        }

        //GET LoginPage
        public IActionResult LoginPage()
        {
            return View();
        }
        [HttpPost("LoginPage")]
        public async Task<IActionResult> LoginPage(string loginid, string password)
        {
            Login clogin = null;
            Login login = null;

            //togetdatabase values into a List<>
            List<Login> list = await _context.Login.ToListAsync();

            //List<>, many Login Objects
            for (int i = 0; i < list.Count; i++)
            {
                clogin = list[i];
                Console.WriteLine(clogin.LoginID + loginid);
                if (clogin.LoginID.Equals(loginid))
                {
                    login = clogin;
                }
            }
            clogin = null;
            if (login == clogin || !login.LoginID.Equals(loginid) || !login.Password.Equals(password))
            {
                //failed to log in
                string failedLogIn = "Wrong Username/Password Entered!";
                ViewData["InputValues"] = failedLogIn;
                return View();
            }
            else
            {
                //check if the user is an admin

                if (!login.IsAdmin.Equals("True"))
                {
                    TempData["curuser"] = login.LoginID;
                    return View("../Home/Index");
                }
                else
                {
                    TempData["curuser"] = login.LoginID;
                    return View("../Products/Create");
                }
            }

        }
    
}
}
