﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace EnsdProj.Controllers.API
{
    public static class SessionExtensions
    {
        public static void Set<T>(this ISession session, string key, T value)
        {
            session.SetString(key, JsonConvert.SerializeObject(value));
        }

        public static T Get<T>(this ISession session, string key)
        {
            var value = session.GetString(key);

            return value == null ? default(T) :
                JsonConvert.DeserializeObject<T>(value);
        }
    }

    public class CartItem
    {
        public CartItem(string _productID, string _title, int _qty, decimal _price)
        {
            this.ProductID = _productID;
            this.Title = _title;
            this.Qty = _qty;
            this.Price = _price;
        }
        public string ProductID { get; set; }
        public string Title { get; set; }
        public int Qty { get; set; }
        public decimal Price { get; set; }
    }


    [Route("api/[controller]")]
    [ApiController]
    public class ShoppingCartController : ControllerBase
    {
        string SessionKeyName = "myshoppingcart";
        // GET: api/ShoppingCart
        [HttpGet]
        public IEnumerable<CartItem> Get()
        {
            Dictionary<string, CartItem> cart;
            if (HttpContext.Session.GetString(SessionKeyName) == null)
            {
                cart = new Dictionary<string, CartItem>();
            }
            else
            {
                cart = HttpContext.Session
                        .Get<Dictionary<string, CartItem>>(SessionKeyName);
            }
            return cart.Values;
        }


        // GET: api/ShoppingCart/5
        [HttpGet("{id}", Name = "Get")]
        public IEnumerable<CartItem> Get(string id)
        {
            var results = new List<CartItem>();
            if (HttpContext.Session.GetString(SessionKeyName) == null)
                return results;
            else
            {
                var cart = HttpContext.Session
                          .Get<Dictionary<string, CartItem>>(SessionKeyName);
                // search for the bookid
                CartItem item;
                if (cart.TryGetValue(id, out item))
                {
                    results.Add(item);
                }
                return results;
            }
        }


        // POST: api/ShoppingCart
        [HttpPost]
        public void Post([FromBody] string value)
        {
            CartItem item = JsonConvert.DeserializeObject<CartItem>(value);
            Dictionary<string, CartItem> cart;
            if (HttpContext.Session.GetString(SessionKeyName) == null)
            {
                cart = new Dictionary<string, CartItem>();
            }
            else
            {
                cart = HttpContext.Session
                      .Get<Dictionary<string, CartItem>>(SessionKeyName);
            }

            if (!cart.ContainsKey(item.ProductID))
            {
                cart.Add(item.ProductID, item);
            }
            else
            {
                var oItem = cart[item.ProductID];
                oItem.Qty += item.Qty;
                cart[item.ProductID] = oItem;
            }
            HttpContext.Session
                  .Set<Dictionary<string, CartItem>>(SessionKeyName, cart);
        }
    

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(string id)
        {
            Dictionary<string, CartItem> cart;
            if (HttpContext.Session.GetString(SessionKeyName) == null)
            {
                cart = new Dictionary<string, CartItem>();
            }
            else
            {
                cart = HttpContext.Session
                      .Get<Dictionary<string, CartItem>>(SessionKeyName);
            }
            if (cart.ContainsKey(id))
            {
                cart.Remove(id);
            }
            HttpContext.Session
                 .Set<Dictionary<string, CartItem>>(SessionKeyName, cart);
        }

    }
}
