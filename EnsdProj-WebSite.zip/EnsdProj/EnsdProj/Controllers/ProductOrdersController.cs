﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace EnsdProj.Models
{
    public class ProductOrdersController : Controller
    {
        private EnsdProjContext db = new EnsdProjContext();
        private readonly EnsdProjContext _context;

        public ProductOrdersController(EnsdProjContext context, IHostingEnvironment _appEnvironment)
        {
            _context = context;
        }


        /*public ProductOrdersController(EnsdProjContext context)
            {
                _context = context;
            }
          // GET: ProductOrders
             public async Task<IActionResult> Index()
           {
               var ensdProjContext = _context.ProductOrder.Include(p => p.Order);
               return View(await ensdProjContext.ToListAsync());

           }*/


        // GET: Products
        public async Task<IActionResult> Index(string searchString)
        {
            var products = from b in _context.Product
                           select b;

            if (!String.IsNullOrEmpty(searchString))
            {
                products = products.Where(s => s.Name.Contains(searchString));
            }

            return View(await products.ToListAsync());

        }



        // GET: ProductOrders/Details/5
        public async Task<IActionResult> Details(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var product = await _context.Product
                .FirstOrDefaultAsync(m => m.ID == id);
            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }


      /*  private bool ProductOrderExists(string id)
        {
            return _context.ProductOrder.Any(e => e.ID == id);
        }  */
    }
}
