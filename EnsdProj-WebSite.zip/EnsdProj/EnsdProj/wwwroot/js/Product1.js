﻿function show(input) {
    debugger;


    var validExtensions = ['jpg', 'png', 'jpeg']; //array of valid extensions
    var fileName = input.files[0].name;

    var fileNameExt = fileName.substr(fileName.lastIndexOf('.') + 1);
    if ($.inArray(fileNameExt, validExtensions) == -1) {
        input.type = ''
        input.type = 'file'
        $('#user_img').attr('src', "");
        alert("Only these file types can be used: " + validExtensions.join(', '));
    }
    else {
        //get image file byte and encode it with base64 
        if (input.files && input.files[0]) {
            var filerdr = new FileReader();

            filerdr.onload = function (e) {
                //alert(e.target.result+"works");
                $('#user_img').attr('src', e.target.result);
                //input box
                document.getElementById("imgpat").value = e.target.result;
                alert(e.target.result);
            }
            filerdr.readAsDataURL(input.files[0]);
        }
    }



}