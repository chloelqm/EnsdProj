﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EnsdProj.Models
{
    public class Order
    {
        public string OrderID { get; set; }
        public string CustomerID { get; set; }

        [Display(Name= "Order Date")]
        [DataType(DataType.Date)]
        public DateTime OrderDate { get; set; }

        public string Name { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        [DataType(DataType.Currency)]
        public decimal Price { get; set; }
        public List<ProductOrder> ProductOrders { get; set; }
    }
}
