﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EnsdProj.Models
{
    public class Product
    {
        public string ID { get; set; }
        public string Name { get; set; }
        public string Desc { get; set; }
        public string Size { get; set; }
        public string Quantity { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        [DataType(DataType.Currency)]
        public decimal Price { get; set; }
        public List<ProductOrder> ProductOrders { get; set; }

        public string ProdIamges { get; set; }
    }
}
