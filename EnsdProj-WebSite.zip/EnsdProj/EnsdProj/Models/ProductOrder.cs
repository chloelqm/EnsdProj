﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc;

namespace EnsdProj.Models
{
    public class ProductOrder
    {
        public string ID { get; set; }
        public Product Product { get; set; }

        public string OrderID { get; set; }
        public Order Order { get; set; }

    }
}
