package sg.edu.nyp.app;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class CheckoutAdapter extends ArrayAdapter<Tops> {
    private Tops[] data;

    public CheckoutAdapter(Context context, Tops[] data) {
        super(context, 0, data);
        this.data = data;
    }

    @NonNull
    @Override
    public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        View itemView = convertView;
        if (itemView == null) {
            itemView = ((Activity) getContext()).getLayoutInflater().inflate(R.layout.activity_checkout_detail, null);
        }

        TextView textViewID = itemView.findViewById(R.id.textViewID);
        TextView textViewName = itemView.findViewById(R.id.textViewName);
        TextView textViewDescription = itemView.findViewById(R.id.textViewDescription);
        TextView textViewSize = itemView.findViewById(R.id.textViewSize);
        TextView textViewQuantity = itemView.findViewById(R.id.textViewQuantity);
        TextView textViewPrice = itemView.findViewById(R.id.textViewPrice);
        ImageView imageViewProductCheckout = itemView.findViewById(R.id.imageViewProductCheckout);

        Button buttonAddToCart = itemView.findViewById(R.id.buttonAddToCart);

        //textViewID.setText((data[position].getId()));
        final Tops t = data[position];
        textViewName.setText(t.getName());
        textViewDescription.setText(t.getDesc());
        textViewSize.setText(t.getSize());
        textViewQuantity.setText(t.getQuantity() + "");
        textViewPrice.setText(t.getPrice() + "");

        try{
            String base64String = t.getImage();
            String base64Image = base64String.split(",")[1];

            byte[] decodedString = Base64.decode(base64Image, Base64.DEFAULT);
            Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);

            imageViewProductCheckout.setImageBitmap(decodedByte);
        }
        catch(Exception ex){

        }


        return itemView;
    }

}
