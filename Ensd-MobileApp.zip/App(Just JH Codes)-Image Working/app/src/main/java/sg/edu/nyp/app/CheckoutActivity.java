package sg.edu.nyp.app;


import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONObject;

public class CheckoutActivity extends AppCompatActivity {

    ListView listViewCart;
    Button showNotification;
    NotificationCompat.Builder mBuilder;
    PendingIntent mResultPending;
    TaskStackBuilder mTaskStackBuilder;
    Intent mResult;
    NotificationManager nNotificationManager;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        showNotification = findViewById(R.id.buttonConfirm);

        mBuilder = new NotificationCompat.Builder(this);
        mBuilder.setSmallIcon(R.mipmap.ic_launcher);
        mBuilder.setContentTitle("Notification from Momento Mori");
        mBuilder.setContentText("Your purchase has been confirmed!");

        mResult = new Intent(this,MainActivity.class);
        mTaskStackBuilder = TaskStackBuilder.create(this);

        mTaskStackBuilder.addParentStack(CheckoutActivity.this);

        mTaskStackBuilder.addNextIntent(mResult);
        mResultPending = mTaskStackBuilder.getPendingIntent(0,PendingIntent.FLAG_UPDATE_CURRENT);
        mBuilder.setContentIntent(mResultPending);

        nNotificationManager = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);

        showNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nNotificationManager.notify(1,mBuilder.build());
            }
        });

        listViewCart = findViewById(R.id.listViewCart);
        Tops[] statusArray = new Tops[0];
        CheckoutAdapter adapter = new CheckoutAdapter(CheckoutActivity.this,MainActivity.cart.toArray(statusArray));

        listViewCart.setAdapter(adapter);



    }

}
