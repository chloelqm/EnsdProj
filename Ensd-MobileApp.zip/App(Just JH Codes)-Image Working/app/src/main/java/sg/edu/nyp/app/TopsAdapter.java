package sg.edu.nyp.app;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class TopsAdapter extends ArrayAdapter<Tops> {

    private Tops[] data;

    public TopsAdapter(Context context, Tops[] data)
    {
        super(context, 0,data);
        this.data = data;
    }

    @NonNull
    @Override
    public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        View itemView = convertView;
        if (itemView == null)
        {
            itemView = ((Activity)getContext()).getLayoutInflater().inflate(R.layout.avtivity_tops_detail,null);
        }

        TextView textViewID = itemView.findViewById(R.id.textViewID);
        TextView textViewName = itemView.findViewById(R.id.textViewName);
        TextView textViewDescription = itemView.findViewById(R.id.textViewDescription);
        TextView textViewSize = itemView.findViewById(R.id.textViewSize);
        TextView textViewQuantity = itemView.findViewById(R.id.textViewQuantity);
        TextView textViewPrice = itemView.findViewById(R.id.textViewPrice);
        ImageView imageViewProduct = itemView.findViewById(R.id.imageViewProduct);

        Button buttonAddToCart = itemView.findViewById(R.id.buttonAddToCart);

        //textViewID.setText((data[position].getId()));
        final Tops t = data[position];
        textViewName.setText(t.getName());
        textViewDescription.setText(t.getDesc());
        textViewSize.setText(t.getSize());
        textViewQuantity.setText(t.getQuantity()+"");
        textViewPrice.setText(t.getPrice()+ "");
        try{
            String base64String = t.getImage();
            String base64Image = base64String.split(",")[1];

            byte[] decodedString = Base64.decode(base64Image, Base64.DEFAULT);
            Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);

            imageViewProduct.setImageBitmap(decodedByte);
        }
        catch(Exception ex){

        }


        //imageViewProduct.setImageResource(Integer.parseInt(t.getImage()));






        buttonAddToCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.cart.add(new Tops(t.getId(),t.getName(),t.getDesc(),t.getSize(),t.getQuantity(),t.getPrice(),t.getImage()));
                Toast.makeText(getContext(), "Item added", Toast.LENGTH_LONG).show();
            }
        });
        return itemView;
    }


}
