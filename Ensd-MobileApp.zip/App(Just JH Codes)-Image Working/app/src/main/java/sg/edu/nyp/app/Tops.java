package sg.edu.nyp.app;

public class Tops {

    private String id;
    private String name;
    private String desc;
    private String size;
    private int quantity;
    private double price;
    private String image;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getImage() {
        return image;
    }

    public Tops(String id, String name, String desc, String size, int quantity, double price, String image) {
        this.id = id;
        this.name = name;
        this.desc = desc;
        this.size = size;
        this.quantity = quantity;
        this.price = price;
        this.image = image;
    }
}
