package sg.edu.nyp.app;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;

public class HomePg extends AppCompatActivity {

    ListView listViewTop;
    ImageView imageViewProducts;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepg);
        //topsArrayList.addAll(Arrays.asList(getResources().getStringArray(R.array.array_tops)));

        String username = getIntent().getStringExtra("LoginId");

        TextView tv = (TextView)findViewById(R.id.textViewUsername);
        tv.setText(username);

        imageViewProducts = findViewById(R.id.imageViewProduct);
        listViewTop = findViewById(R.id.listViewTops);
        listViewTop.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Tops tops = topsArrayList.get(position);

            }
        });

        DownloadTopTask task = new DownloadTopTask();

        task.execute();

        Button buttonCheckout = findViewById(R.id.buttonCheckout);
        buttonCheckout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomePg.this,CheckoutActivity.class);
                startActivityForResult(intent,69);

            }
        });
    }

    ArrayList<Tops> topsArrayList = new ArrayList<Tops>();
    public class DownloadTopTask extends AsyncTask<Void,String,Boolean>
    {
        @Override
        protected Boolean doInBackground(Void... voids)
        {

            ArrayList<Tops> list = new ArrayList<>();
            try
            {
                String json = "";
                URL url = new URL("https://ensdproj123.azurewebsites.net/api/ProductsApi");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setDoInput(true);
                conn.connect();

                int responseCode = conn.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK)
                {
                    // Retrieve the JSON data as a string;
                    InputStream inputStream = conn.getInputStream();
                    BufferedReader buffer = new BufferedReader(new InputStreamReader(inputStream));
                    String s = "";
                    while ((s = buffer.readLine())!= null)
                        json += s;

                    // Process the download JSON
                    JSONArray jsonArray = new JSONArray(json);

                    jsonArray.getJSONObject(0);

                    for (int i = 0; i < jsonArray.length(); i ++)
                    {
                        JSONObject top = jsonArray.getJSONObject(i);

                        // Get ID
                        String id = top.getString("id");

                        // Get Name
                        String name = null;
                        if (!top.isNull("name"));
                        name = top.getString("name");

                        // Get Description
                        String desc = null;
                        if (!top.isNull("desc"));
                        desc = top.getString("desc");

                        // Get Size
                        String size = null;
                        if (!top.isNull("size"))
                            size = top.getString("size");

                        // Get Quantity
                        int quantity = 0;
                        if (!top.isNull("quantity"))
                        {
                            String quantityString = top.getString("quantity");
                            quantity = Integer.parseInt(quantityString);
                        }

                        // Get Price
                        double price = 0.0;
                        if (!top.isNull("price"))
                        {
                            String priceString = top.getString("price");
                            price = Double.parseDouble(priceString);
                        }

                        // Get Product Image
                        String image = top.getString("prodIamges");

                        Tops newTops = new Tops(id,name,desc,size,quantity,price,image);
                        topsArrayList.add(newTops);
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return true;


    }



        @Override
        protected void onPostExecute(Boolean aBoolean) {
            if (topsArrayList.size() > 0) {
                Tops[] statusArray = new Tops[0];
                TopsAdapter adapter = new TopsAdapter(HomePg.this, topsArrayList.toArray(statusArray));

                listViewTop.setAdapter(adapter);
            }
            else {
                Toast.makeText(HomePg.this, "Not added", Toast.LENGTH_LONG).show();
            }
        }
    }


}