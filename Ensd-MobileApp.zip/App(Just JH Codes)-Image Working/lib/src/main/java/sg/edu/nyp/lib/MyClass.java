package sg.edu.nyp.lib;

public class MyClass {
}
